#ifndef _ITHEME_H_
#define _ITHEME_H_

#include "..\\include\classes\IRoot.h"

class ITheme: public IRoot
{
public:
  virtual int method1();
  virtual int GetFont(char* DispName, char* FontName, IRoot** ppFont);
  virtual int method3();
};

#endif