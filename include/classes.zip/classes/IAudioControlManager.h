#ifndef _IAUDIOCONTROLMANAGER_H_
#define _IAUDIOCONTROLMANAGER_H_

#include "..\\include\classes\IRoot.h"
#include "..\\include\classes\IAudioControl.h"

class IAudioControlManager;

class IAudioControlManager: public IRoot
{
public:
  virtual int CreateAudioControl(IAudioControl** pIAudioControl);
};

#endif
