#ifndef __ICOPSMANAGER_H__
#define __ICOPSMANAGER_H__

#include "..\\classes\IRoot.h"
#include "..\\classes\ISIMLock.h"
#include "..\\classes\IPhoneLock.h"

UUID CID_CCopsManager = {0xA8, 0xB8, 0x92, 0x61, 0xB0, 0x06, 0x4F, 0x5B, 0xBC, 0x57, 0xA1, 0xC6, 0xF1, 0x2C, 0x06, 0x02};
UUID IID_ICopsManager = {0xFC, 0x49, 0x8A, 0x1A, 0xAF, 0x4B, 0x42, 0xC2, 0x80, 0x12, 0x98, 0x45, 0x12, 0x10, 0xFC, 0x31};

class ICopsManager;

class ICopsManager: public IRoot
{
public:
  virtual int CreateSimLock( ISimLock** pISimLock );
  virtual int CreatePhoneLock( IPhoneLock** pIPhoneLock )
  virtual int method3();
  virtual int GetSystemIMEI( char* IMEI ); 
};

#endif
