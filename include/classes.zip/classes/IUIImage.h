#ifndef _IUIIMAGE_H_
#define _IUIIMAGE_H_

#include "..\\include\classes\IRoot.h"

class IUIImage: public IRoot
{
public:
  //virtual int GetDimensions( TUnsigned* pWidth, TSizeUnit* pWidthUnit, TUnsigned* pHeight, TSizeUnit* pHeightUnit );
  virtual RVoid GetDimensions( void* pWidth, void* pWidthUnit, void* pHeight, void* pHeightUnit );
  virtual RVoid CreateRenderer( TBool* pIUIImageRenderer );
  virtual RVoid IsAnimation( TBool* IsAnimation );
  virtual RVoid IsScalable( TBool* IsScalable );
};

#endif
