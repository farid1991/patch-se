#ifndef _IFONTMANAGER_H_
#define _IFONTMANAGER_H_

#include "..\\include\classes\IRoot.h"
#include "..\\include\classes\IFontFactory.h"

class IFontManager: public IRoot
{
public:
#if defined(DB3150v1)
  virtual void unk();
#endif
  virtual void GetFontFactory( IFontFactory** ppFontFactory );
};

#endif
