#ifndef __IUICLIPBOARD_H__
#define __IUICLIPBOARD_H__

#include "..\\classes\IRoot.h"
#include "..\\classes\IUIText.h"

class IUIClipboard: public IUnknown
{
public:
    virtual int GetBuffer(void **buffer);
    virtual int SetIUIText(IUIText *pIUIText);
    virtual int GetIUIText(IUIText **ppIUITextPointer);
    virtual int Clear();
    virtual int isEmpty();
};


#endif
