
#include "..\\classes\IUIRoot.h";
#include "..\\classes\IUIImage.h";
#include "..\\classes\IUITextFactory.h";
#include "..\\classes\IUISoftkeyFactory.h";
#include "..\\classes\IUIBrowserFactory.h";
#include "..\\classes\IUIImageCanvasFactory.h";
#include "..\\classes\IUIImageIconFactory.h";
#include "..\\classes\IUIFontFactory.h";
#include "..\\classes\IUIPhonebookFactory.h";
#include "..\\classes\IUILanguageSettings.h";
#include "..\\classes\IUIStandby.h";
#include "..\\classes\IUIScreenSaver.h";
#include "..\\classes\IUIVolumeControl.h";
#include "..\\classes\IUIFeedbackTicker.h";
#include "..\\classes\IUIKeySoundControl.h";
#include "..\\classes\IUIImageManager.h";

UUID IID_IUIManager = { 0x2D, 0x5F, 0xED, 0xED, 0xE5, 0xAA, 0x43, 0xCC, 0x96, 0x08, 0x7D, 0xF2, 0xE8, 0x62, 0x36, 0x44 };
UUID CID_CUIManager = { 0x1B, 0xFA, 0xCD, 0x74, 0x2D, 0x0F, 0x47, 0x05, 0xB6, 0xEC, 0x24, 0x56, 0xC1, 0x4F, 0xAF, 0x48 };

/**
 * User interface gui manager interface
 *
 * Contains factory methods for GUI objects
 */
class IUIManager : public IUIRoot
{
public:
	virtual void* unk_14();
	virtual int GetTextFactory( IUITextFactory** ppIUITextFactory);
	virtual void* unk_1C();
	virtual void* unk_20();
	virtual int GetSoftkeyFactory( IUISoftkeyFactory** ppIUISoftkeyFactory);
	virtual int GetBrowserFactory( IUIBrowserFactory** ppIUIBrowserFactory);
	virtual int GetImageCanvasFactory( IUIImageCanvasFactory** ppIUIImageCanvasFactory);
	virtual int GetImageIconFactory( IUIImageIconFactory** ppIUIImageIconFactory);
	virtual int GetPhonebookFactory( IUIPhonebookFactory** ppIUIPhonebookFactory);
	virtual int GetFontFactory( IUIFontFactory** ppIUIFontFactory);
	virtual int GetLanguageSettings( IUILanguageSettings** ppIUILanguageSettings);
	virtual int GetStandby( IUIStandby** ppIUIStandby);
	virtual int GetScreenSaver( IUIScreenSaver** ppIUIScreenSaver);
	virtual int GetVolumeControl( IUIVolumeControl** ppIUIVolumeControl);
	virtual int GetFeedbackTicker( IUIFeedbackTicker** ppIUIFeedbackTicker);
	virtual void* unk_50();
	virtual int GetKeySoundControl( IUIKeySoundControl** ppIUIKeySoundControl);
	virtual int GetImageManager( IUIImageManager** ppIUIImageManager);
};

