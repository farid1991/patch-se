#ifndef __ISIMLOCK_H__
#define __ISIMLOCK_H__

#include "..\\classes\IRoot.h"

class ISimLock;

typedef struct
{
  int	unk1;
  int	Net; 			// 0 - unlock;
  char	dummy_1[0x18];
  int	SubNet;  		// 0 - unlock;
} TSimLockProperties; 	//size 0x98?

class ISimLock: public IRoot
{
public:
  virtual int unk_0x10();
  virtual int SimLockProperties(TSimLockProperties* simlocksProperties);
  virtual int unk_0x18();
};
#endif
