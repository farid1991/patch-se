#ifndef __ISEMCREGISTRYACCESS_H__
#define __ISEMCREGISTRYACCESS_H__

#include "..\\classes\IRegistryKey.h"
#include "..\\classes\OPA_types.h"
#include "..\\classes\IRoot.h"

class IRegistryAccess : public IUnknown // 0x119A9204
{
public:
  virtual int ReadUnsignedInt(TAscii* absoluteValuePath, TUnsigned * pUnsigned);
  virtual int ReadString(TAscii* absoluteValuePath, TUnsigned MaxLengh, TAscii* String, TUnsigned* pActualLength);
  virtual int ReadWString(TAscii* absoluteValuePath, TUnsigned MaxLengh, TChar* WString, TUnsigned* pActualLength);
  virtual int ReadBinary(TAscii* absoluteValuePath, TUnsigned Size, void * data, TUnsigned * pActualSize);
  virtual int WriteUnsignedInt(TAscii* absoluteValuePath, TUnsigned UnsignedInt);
  virtual int WriteString(TAscii* absoluteValuePath, TAscii* String);
  virtual int WriteWString(TAscii* absoluteValuePath, TChar* WString);
  virtual int WriteBinary(TAscii* absoluteValuePath, TVoid* pData, TUnsigned dataSize);
  virtual int EnableValidation();
  virtual int DisableValidation();
};

#endif
