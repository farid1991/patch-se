#ifndef __IUITEXTFACTORY_H__
#define __IUITEXTFACTORY_H__

#include "..\\classes\IRoot.h"
#include "..\\classes\IUIText.h"

UUID CID_CUITextFactory = {0xEA,0xED,0x04,0x64,0x00,0x73,0x41,0x81,0xBD,0xE3,0xFB,0x31,0x9F,0xDB,0xDF,0xBC};
UUID IID_IUITextFactory = {0xFB,0xE8,0xC1,0xCC,0x97,0x35,0x49,0xD9,0x95,0x8E,0x3E,0x9D,0x99,0x82,0x27,0xB3};
  
class IUIText: public IUnknown
{
public:
    virtual int method_0x10();
    virtual int get_text(wchar_t *ws, int max_len, int *len);
    virtual int method_0x18();
    virtual int get_len(int *len);
};

class IUITextFactory: public IUnknown
{
public:
    virtual int method_0x10();
    virtual int CreateFromAscii( wchar_t ascii, int len, IUIText **ppIUITextPointer );
    virtual int CreateFromRaw( wchar_t *ws, int len, IUIText **ppIUITextPointer );
    virtual int CreateFromTextId( TEXTID, IUIText **ppIUITextPointer );
    virtual int GetStringFromTextId( TEXTID, wchar_t** wstr, int maxlen );
    virtual int GetTextIdLength( TEXTID, int* length );
    virtual int method_0x28();
    virtual int ConcatenateIUITexts();
};

#endif
