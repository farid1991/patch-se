#ifndef __ICBMUSICSERVER_H__
#define __ICBMUSICSERVER_H__

#include "..\\include\classes\IRoot.h"
#include "..\\include\classes\IMusicServer.h"

#include "..\\include\types\MusicServer_types.h"

class ICBMusicServer;

class ICBMusicServer: public IRoot
{
public:
    virtual void OnInitiated(int status, int track_count, bool random, bool loop, int ClientData);
    virtual void OnDestroy(int ClientData);
    virtual void OnDestroyed(int ClientData);
    virtual void OnStopped(TMusicServer_Cause cause, TMusicServer_Time time, int ClientData);
    virtual void OnStateChanged(TMusicServer_State state, TMusicServer_Time elapsedtime, int ClientData);
    virtual void OnTimeFeedback(TMusicServer_Time elapsedtime, int ClientData);
    virtual void OnAudioMuted(TMusicServer_MuteReason muteReason, int ClientData);
    virtual void OnNbrOfItemsChanged(int track_count, int ClientData, int result);
    virtual void OnItemChanged(int status, int track_id, TMusicServer_Time Position, TMusicServer_Action Action,
                               wchar_t * fullpath, int path_lengh, wchar_t * Title, int TitleLengh, wchar_t * Artist, int ArtistLengh,
                               wchar_t * Album, int AlbumLengh, TMusicServer_Time FullTime, bool isAlumArt, bool isDRMProtected, bool isRealMediaFile, int ClientData);
    virtual void OnApplicationStarted(bool started, int ClientData);
    virtual void OnError(int error, int ClientData);
};

#endif
