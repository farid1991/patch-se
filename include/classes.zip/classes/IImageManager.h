#ifndef _IUIIMAGE_MANAGER_H_
#define _IUIIMAGE_MANAGER_H_

#include "..\\include\interface\IRoot.h"
#include "..\\include\interface\IUIImage.h"

class IImageManager;

class IImageManager: public IRoot
{
public:
  virtual int CreateFromPath(wchar_t* fPath, wchar_t* fName, char* pMime, long mimeLength, IUIImage** ppUIImage);
  virtual int CreateFromCanvas(IRoot* pGC, IUIImage** ppUIImage);
  virtual int CreateFromIcon(long imageID, IUIImage** ppUIImage);
#if defined(DB3200) || defined(DB3210) || defined(DB3350)
  virtual int CreateFromIconWithIconSet(long imageID, IRoot* pIconSet,IUIImage ** pUIImage);
#endif
  virtual int CreateFromMemory(char * buf_image,long bufferSize,wchar_t * extension,long extensionLength,char * pMime,long mimeLength,IUIImage ** pUIImage);
  virtual int CreateFromSimpleLockableBuffer(IRoot* pISimpleLockableBuffer, long imageDataSize, wchar_t* extension, long extensionLength, char* pMime, long mimeLength, IUIImage** ppUIImage);
  virtual int Draw(IUIImage* pUIImage, IRoot* pGC,TUIRectangle rect);
};


#endif
