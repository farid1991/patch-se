#ifndef _IUISOFTKEY_H_
#define _IUISOFTKEY_H_

#include "..\\include\classes\IUIRoot.h"

/** 
 * Softkey interface
 *
[
  uuid(833e3017-7666-4269-b955-764c1e84384f)
]
*/

class IUISoftkey : public IUIRoot
{
public:
  virtual int SubscribeToSoftkeyEvents( ICBUISoftkey* pICBUISoftkey,
										TMsgBase      msgBase,
										TClientData   clientData,
										THnd*         pSubscriptionHandle );
  virtual int SubscribeToSoftkeyDisableEvents( ICBUISoftkey* pICBUIDisableSoftkey,
											   TMsgBase      msgBase,
											   TClientData   clientDataDisableEvent,
											   THnd*         pSubscriptionHandle );
  virtual int UnsubscribeFromSoftkeyEvents( THnd SubscriptionHandle );
  virtual int UnsubscribeFromSoftkeyDisableEvents( THnd SubscriptionHandle );
  virtual int SetText( IUIText* pIUIText );
  virtual int SetLongSKButtonText( IUIText* pIUILongSKButtonText );
  virtual int GetLongSKButtonText( IUIText** ppIUILongSKButtonText );
  virtual int SetTexts( IUIText* pIUIButtonText, IUIText* pIUIMenuText );
  virtual int SetIcon( IUIImage* pIUIImage );
  virtual int MoveItemAfter( IUISoftkey* pIUISoftkeyAnchor );
  virtual int MoveItemBefore( IUISoftkey* pIUISoftkeyAnchor );
  virtual int MoveItemFirst( void );
  virtual int SuppressDefaultAction( void );
  virtual int DisallowSuppress( void );
  virtual int SetVisible( TBool visible );
  virtual int SetEnabled( TBool enabled );
  virtual int SetDisabledMessage( IUIText* pIUIDisabledMessage );
  virtual int SetDisabledAction( void );
  virtual int SetItemAsSubItem( IUISoftkey*  pIUISubItem );
  virtual int SetSubItemHighlight( IUISoftkey*  pIUISubItem );
  virtual int Disconnect( void );
  virtual int PlaceSKBelowFocusedObj( TBool placeSKBelowFocusedObj );
  virtual int HideSoftkeys( void );
  virtual int ShowSoftkeys( void );
  virtual int SoftkeysBgTransparant( void );
  virtual int SoftkeysBgOpaque( void );
  virtual int SubActionPressedNotification( subActionPressedNotification );
  virtual int SetItemOnKey( KeySym key, KeyActionType keyActionType );
  virtual int RemoveItemFromKey( KeySym key, KeyActionType keyActionType );
  virtual int SetHelpText( IUIText* pIUIHelpText );
  virtual int SetTextColor( FUint32 textColor );
}

#endif