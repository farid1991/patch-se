#ifndef __IMEDIACENTERMANAGER_H__
#define __IMEDIACENTERMANAGER_H__

#include "..\\interface\IRoot.h"
#include "..\\interface\Basic_types.h"

UUID IID_IUIMediaCenterManager = { 0xCB,0x76,0x32,0x14,0x31,0x9C,0x47,0x1D,0x99,0xA2,0x7D,0x54,0x7C,0x3C,0xDA,0x9F };
UUID CID_CUIMediaCenterManager = { 0xF0,0x8A,0xB9,0xCA,0xB9,0xCA,0x44,0x1D,0xAD,0x3F,0x0F,0x03,0x99,0xDB,0x2F,0x26 };

class ICBUIMediaCenterSettings;
class IUIMediaCenterSettings;
class IUIMediaCenterManager;


typedef FSint32 TUIMediaCenterIndex;
typedef FUint32 TUIMediaCenterCount;
typedef FUint32 TUIMediaCenterSoftkeyId;
typedef FUint32 TUIMediaCenterData;
typedef FUint32 TUIMediaCenterSelector;

typedef enum 
{
  TUIMediaCenterLookAndFeel_STANDARD,
  TUIMediaCenterLookAndFeel_NO_HISTORY_BAR,
  TUIMediaCenterLookAndFeel_BIG_ICONS,
  TUIMediaCenterLookAndFeel_BIG_ICONS_VIDEO,
  TUIMediaCenterLookAndFeel_TIME
} TUIMediaCenterLookAndFeel;


typedef enum
{
  TUIMediaCenterTransition_GRID
} TUIMediaCenterTransition;


typedef enum
{
  TUIMediaCenterType_INTERNAL_NODE,
  TUIMediaCenterType_LEAF_NODE,
  TUIMediaCenterType_LEAF_NODE_PSEUDO_CHILDREN,
  TUIMediaCenterType_INTERNAL_NODE_NEW_CONTENT_PROVIDER
} TUIMediaCenterType;


typedef enum
{
  TUIMediaCenterOrientation_VERTICAL,  ///< Vertical orientation.
  TUIMediaCenterOrientation_HORIZONTAL ///< Horizontal orientation.
} TUIMediaCenterOrientation;


typedef enum
{
  TUIMediaCenterSearchMethod_DIGITS,             ///< Only digits.
  TUIMediaCenterSearchMethod_LETTERS_AND_DIGITS  ///< Both letters and digits.
} TUIMediaCenterSearchMethod;


typedef enum
{
  TUIMediaCenterSelectorItem_ID = 0x1,
  TUIMediaCenterSelectorItem_INDEX = 0x2,
  TUIMediaCenterSelectorItem_TYPE = 0x4,
  TUIMediaCenterSelectorItem_DATA = 0x8,
  TUIMediaCenterSelectorItem_TITLE = 0x10,
  TUIMediaCenterSelectorItem_HISTORY_TITLE = 0x20,
  TUIMediaCenterSelectorItem_SUB_TITLE = 0x40,
  TUIMediaCenterSelectorItem_ICON = 0x80,
  TUIMediaCenterSelectorItem_SMALL_ICON = 0x100,
  TUIMediaCenterSelectorItem_SECONDARY_SMALL_ICON = 0x200,
  TUIMediaCenterSelectorItem_HISTORY_ICON = 0x400,
  TUIMediaCenterSelectorItem_HISTORY_SMALL_ICON = 0x800,
  TUIMediaCenterSelectorItem_ENABLED = 0x1000,
  TUIMediaCenterSelectorItem_ICON_COLORIZATION = 0x2000,
  TUIMediaCenterSelectorItem_VIEW_ID = 0x4000,
  TUIMediaCenterSelectorItem_FIRST_BIG_ICON = 0x8000,
  TUIMediaCenterSelectorItem_REST_OF_BIG_ICON = 0x10000,
  TUIMediaCenterSelectorItem_ALL = 0xFFFFF
} TUIMediaCenterSelectorItem;


typedef enum
{
  TUIMediaCenterSoftkeyUpdateRequestKind_ONE_SLOT_AVAILABLE,
  TUIMediaCenterSoftkeyUpdateRequestKind_TWO_SLOTS_AVAILABLE,
  TUIMediaCenterSoftkeyUpdateRequestKind_PREPARE_FOR_MENU
} TUIMediaCenterSoftkeyUpdateRequestKind;


typedef enum
{
  TUIMediaCenterResource_AUDIO,
  TUIMediaCenterResource_VIDEO
} TUIMediaCenterResource;


typedef enum
{
  TUIMediaCenterCloseRefusal_NORMAL,
  TUIMediaCenterCloseRefusal_ABNORMAL
} TUIMediaCenterCloseRefusal;


typedef enum
{
  TUIMediaCenterView_PRIMARY,
  TUIMediaCenterView_EXTERNAL
} TUIMediaCenterView;

class ICBUIMediaCenterSettings : public IUnknown
{
public:
  virtual void OnOrientationRetrieved(TUIMediaCenterOrientation orientation, int ClientData);
  virtual void OnAutoRotateRetrieved(char AutoRotate, int ClientData);
};

class IUIMediaCenterSettings : public IUnknown
{
public:
  virtual int GetOrientation(ICBUIMediaCenterSettings * pICBUIMediaCenterSettings, u16 msgBase, int ClientData);
  virtual int IsAutoRotateEnabled(ICBUIMediaCenterSettings * pICBUIMediaCenterSettings, u16 msgBase, int ClientData);
  virtual int SetOrientation(TUIMediaCenterOrientation orientation);
  virtual int LockOrientation(TUIMediaCenterOrientation orientation);
  virtual int UnlockOrientation();
  virtual int DisableEffect();
  virtual int EnableEffect();
};

class IUIMediaCenter : public IRoot
{
public:
  virtual int RegisterContentProvider( ICBUIMediaCenterContentProvider* pICBProvider, TMsgBase msgBase, TClientData clientData, TChar* pId,TUnsigned idSize);
  virtual int RegisterAssociate( ICBUIMediaCenterAssociate* pICBAssociate, TMsgBase msgBase, TClientData clientData, TChar* pId, TUnsigned idSize);
  virtual int UnregisterContentProvider( TChar* pId, TUnsigned idSize);
  virtual int UnregisterAssociate( TChar* pId, TUnsigned idSize);
};

class IUIMediaCenterManager : public IUnknown
{
public:
  virtual int GetMediaCenter(IUIMediaCenter** ppIUIMediaCenter);
  virtual int GetMediaCenterSettings(IUIMediaCenterSettings** ppIUIMediaCenterSettings);
  virtual int GetMediaCenterTree(void** ppIUIMediaCenterTree);
  virtual int GetMediaCenterMultitasking(void** ppIUIMediaCenterMultitasking);
  virtual int GetMediaCenterResource(void** ppIUIMediaCenterResource);
};
