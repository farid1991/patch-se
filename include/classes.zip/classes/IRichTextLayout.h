#ifndef _IRICHTEXTLAYOUT_H_
#define _IRICHTEXTLAYOUT_H_

#include "..\\include\classes\IRoot.h"
#include "..\\include\classes\IRichText.h"

class IRichTextLayout;

/**
 *  A structure for returning information about a layout.
 *
 * \see \ref SEMC_UI_TEXT_RENDERING_LAYOUT_COORDINATE_SYSTEM "Layout Coordinate System"
 */
typedef struct
{
    FSint32      numLines;         ///< number of lines in the layout 
    FSint32      numContainersUsed;///< number of containers actually used 
    TUIRectangle boundingBox;      ///< text layout bounding box 
    TUIRectangle advanceBox;       ///< text layout advance box 
} TUILayoutInfo;

/**
 *  A structure for returning information about a container in the layout.
 *
 *
 * @see \ref SEMC_UI_TEXT_RENDERING_LAYOUT_COORDINATE_SYSTEM "Layout Coordinate System"
 */
typedef struct
{
    FSint32 numLines;          ///< count of lines in the container
    FSint32 firstLineNumber;   ///< index of first line in container
    TUIRectangle boundingBox;  ///< text container bounding box
    TUIRectangle advanceBox;   ///< text container advance box
} TUIContainerInfo;

/**
 *  A structure with information about a TsLayout line.
 *
 * @see \ref SEMC_UI_TEXT_RENDERING_LAYOUT_COORDINATE_SYSTEM "Layout Coordinate System"
 */
typedef struct
{
    FSint32       numGlyphs;    ///< number of glyphs on the line 
    FSint32       startIndex;   ///< IUIRichText character index of first character in line 
    FSint32       endIndex;     ///< IUIRichText character index of last character in line 
    TUIRectangle  boundingBox;  ///< actual "inked" area of the line -- relative to line's origin
    TUIRectangle  advanceBox;   ///< box spanning origin to next advance point -- relative to line's origin 
    FUint8        bidiBaseLevel;///< bidi base level for line -- odd if Right-To-Left, even if Left-To-Right 
    TUIPoint      lineOrigin;   ///< absolute coordinates for line's origin, only meaningful if lineFlags has UI_LINE_DISPLAYED set 
    FUint32       lineFlags;    ///< flags like UI_LINE_COMPOSED and UI_LINE_DISPLAYED 
    FSint32       baseline;     ///< amount to add to lineOrigin.y to get baseline 
    FSint32       top;          ///< amount to add to lineOrigin.y to get top of line (used for overline, and background color)
    FSint32       bottom;       ///< amount to add to lineOrigin.y to get bottom of line (used for background color)
    TUITextAlignment   alignment;///< alignment of line (UIText_alignLeft, UIText_alignRight, or UIText_alignCenter)
} TUILineInfo;

/**
 * A structure with information about a IUIRichTextLayout glyph.
 *
 * @see \ref SEMC_UI_TEXT_RENDERING_LAYOUT_COORDINATE_SYSTEM "Layout Coordinate System"
 */
typedef struct
{
    FSint32      sourceIndex; ///< character index in �UIRichText block 
    FSint32      glyphID;     ///< glyph index in font 
    TUIPosition  x;           ///< the x coordinate relative to the line's origin 
    TUIPosition  y;           ///< the y coordinate relative to the line's origin 
    TUIRectangle boundingBox; ///< bounding box relative to the glyph's position (x,y) 
} TUIGlyphInfo;

class IRichTextLayout: public IRoot
{
public:
  virtual int SetControl(void* pIUIRichTextLayoutControl);
  virtual int GetControl(void** ppIUIRichTextLayoutControl);
  virtual int SetOptions(void* pIUIRichTextLayoutOptions);
  virtual int GetOptions(void* pIUIRichTextLayoutOptions);
  virtual int Subscribe(void* pICBUIRichTextLayout,u16 msgBase,int clientData,unsigned long * pSubscriptionHandle);
  virtual int Unsubscribe(unsigned long SubscriptionHandle);
  virtual int SetText(IRichText* pTextObject);
  virtual int GetText(IRichText** pTextObject);
  virtual int Compose(int lineWidth);
  virtual int ComposeLine(int lineWidth,int ascenderLimit,int descenderLimit,int lineNumber,long * pStartIndex,long * pEndIndex,long * pCharsLeftToCompose);
  virtual int ComposeLineInit(long x,long y,long lineNumber);
  virtual int PositionLine(long x,long y,long lineNumber);
  virtual int ComposeContainers(TUIRectangle * pComposeRect);
  virtual int GetWidthOfLongestRemainingLineBreakSequence(int * pWidth,long * pStartIndex,long * pEndIndex);
  virtual int GetLineInfo(long lineNumber,TUILineInfo *pInfo);
  virtual int MapCharIndex(long index,long * pLineNumber);
  virtual int GetGlyphInfo(long lineNumber,long glyphIndex,bool needBoundingBox,TUIGlyphInfo *pInfo);
  virtual int GetNumberOfLines(long *pNumberOfLines);
  virtual int GetLayoutInfo(TUILayoutInfo *pLayoutInfo);
  virtual int GetContainerInfo(long containerIndex,TUIContainerInfo *pContainerInfo);
  virtual int Display(IRoot* pGC,long x,long y,TUIRectangle *pInvalidateRect);
  virtual int DisplayContainers(IRoot * pGC,long x,long y,TUIRectangle *pInvalidateRect);
  virtual int DisplayLine(IRoot* pGC,long x,long y,TUIRectangle *pInvalidateRect);
  virtual int AddTextContainer(IRoot *pIUITextContainer,long containerID,TUIPoint *pContainerOrigin);
  virtual int RemoveTextContainer(long containerID);
};

#endif
