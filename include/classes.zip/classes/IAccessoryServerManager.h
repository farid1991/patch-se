#ifndef __IMEDIACENTERMANAGER_H__
#define __IMEDIACENTERMANAGER_H__

#include "..\\classes\IRoot.h"
#include "..\\classes\Basic_types.h"

UUID IID_IAccessoryServerManager = { 0xE0, 0x94, 0x4C, 0xC8, 0xBC, 0x11, 0x4a, 0x9d, 0xAB, 0xDF, 0xA9, 0x0C, 0xB1, 0x7D, 0xEF, 0xBB };
UUID CID_CAccessoryServerManager = {  };

typedef enum
{
  AS_AccessoryClass_PHF_1,               ///< PHF1 class; RID value: 0-6
  AS_AccessoryClass_PHF_2,               ///< PHF2 class; RID value: 22-34
  AS_AccessoryClass_PHF_3,               ///< PHF3 class; RID value: 51-63
  AS_AccessoryClass_PHF_4,               ///< PHF4 class; RID value: 79-91
  AS_AccessoryClass_AudioOut,            ///< Audio Video Line Out; RID value: 108-120
  AS_AccessoryClass_AudioIn,             ///< Audio Line In; RID value: 136-148
  AS_AccessoryClass_USBHost,             ///< USB OTG Host; RID value: 165-177
  AS_AccessoryClass_USBSlave_EDB,        ///< USB Slave & EDB; RID value: 193-205
  AS_AccessoryClass_ACB,                 ///< ACB class; RID value: 222-234
  AS_AccessoryClass_USBSlave_Vbus,       ///< USB Slave Vbus ID class; Detected without RID (Not supported yet)
  AS_AccessoryClass_Charger,             ///< USB Charger; Detected with DCIO (Not supported yet)
  AS_AccessoryClass_Idle,                ///< Idle class, i.e. no accessory attached; RID value: 250-256

  //Extend to include stereo jack
  AS_AccessoryClass_PHF_5,               ///< PHF5 class; 3.5mm Stereo jack with Micro phone
  AS_AccessoryClass_AudioOut_StereoJack, ///< Audio Video Line Out from 3.5mm Stereo Jack;

  AS_AccessoryClass_None                 ///< No class
} AS_AccessoryClass_t;

/**
 * The accessory base class tells the client what kind of accessory it is. To have
 * the exact type of the accessory use AS_AccessoryType_t.
 */
typedef enum
{
  AS_AccessoryBaseType_Unknown                = 0,    ///< Unknown basetype
  AS_AccessoryBaseType_CameraFlash            = 1,    ///< Base type for camera flashes
  AS_AccessoryBaseType_InputDevice            = 2,    ///< Base type for input devices
  AS_AccessoryBaseType_Gaming                 = 3,    ///< Base type for gaming accessories
  AS_AccessoryBaseType_Imaging                = 4,    ///< Base type for imaging accessories
  AS_AccessoryBaseType_VehicleHF              = 5,    ///< Base type for vehicle handsfrees
  AS_AccessoryBaseType_SmartPHF               = 6,    ///< Base type for smart PHFs
  AS_AccessoryBaseType_Gadget                 = 7,    ///< Base type for gadget accessories
  AS_AccessoryBaseType_BudgetVehicleHF        = 8,    ///< Base type for budget VHFs
  AS_AccessoryBaseType_BudgetVehicleHF_NoMic  = 9,    ///< Base type for budget VHFs without mic
  AS_AccessoryBaseType_BTHF                   = 10,   ///< Base type for BT handsfree
  AS_AccessoryBaseType_BTVehicle              = 11,   ///< Base type for BT VHFs
  AS_AccessoryBaseType_BTLeisure              = 12,   ///< Base type for BT Leisure (support for A2DP)
  AS_AccessoryBaseType_BTBTL                  = 13,   ///< Base type for BTBTL (BTHF/BHHS and BT A2DP)
  AS_AccessoryBaseType_BTBTLVehicle           = 14,   ///< Base type for BTBTL VHF
  AS_AccessoryBaseType_DeskSpeakerStand       = 15,   ///< Base type for desk speaker stands
  AS_AccessoryBaseType_BudgetDeskSpeakerStand = 16,   ///< Base type for budget desk speaker stands
  AS_AccessoryBaseType_LineInOut              = 17,   ///< Base type for Line In/Out accessories
  AS_AccessoryBaseType_LineIn                 = 18,   ///> Base type for Line In  accessories
  AS_AccessoryBaseType_WLAN                   = 19,   ///> Base type for WLAN  accessories
  AS_AccessoryBaseType_DVBH                   = 20,   ///> Base type for DVBH  accessories	
  AS_AccessoryBaseType_GPS                    = 21,   ///> Base type for GPS  accessories
  AS_AccessoryBaseType_PHF                    = 254   ///< Base type for normal (dumb) PHFs
} AS_AccessoryBaseType_t;

typedef FUint32 AS_AccessoryId_t;
typedef FUint32 AS_AccessoryType_t;

typedef enum
{
  AS_TV_CONNECTED,       ///< TV is attached
  AS_TV_DISCONNECTED     ///< TV is detached
} AS_TV_Connection_t;

typedef struct
{
  AS_AccessoryId_t         accUniqueID;   ///< A unique id
  AS_AccessoryBaseType_t   accBaseType;   ///< The base class of the accessory
  AS_AccessoryType_t       accType;       ///< The unique type of the accessory
  AS_AccessoryClass_t      accClass;      ///< The RID class of the accessory  
  FUint8                   radioAntenna;  ///< Pin number of attached radio antenna, 0 if none
  FUint8                   tvAntenna;     ///< Pin number of attached TV antenna, 0 if none
  AS_TV_Connection_t       tvConnection;  ///< Phone connection status with TV
} AS_AccessoryInformation_t;

const FUint32 AS_MAX_ACCESSORIES = 15;

typedef struct 
{
  AS_AccessoryInformation_t accInfo[AS_MAX_ACCESSORIES];
} AS_AccessoryInformationList_t;

typedef enum
{
  AccessoryProperty_Handsfree = 1,
  AccessoryProperty_Camera = 2,
  AccessoryProperty_Radio = 4,
  AccessoryProperty_MediaPlayer = 8,
  AccessoryProperty_Charger = 16,
  AccessoryProperty_Bluetooth = 32,
  AccessoryProperty_Vehicle = 64,
  AccessoryProperty_Speaker = 128,              // Speaker, as opposed to headphones.
  AccessoryProperty_Stereo = 256,
  AccessoryProperty_ContinuousSoundPath = 512,  // Sound path allocated all the time while connected.
  AccessoryProperty_Lamp = 1024,                // Extern Camera Flash
  AccessoryProperty_Video = 2048                // TV
} TAccessoryProperty_t;

typedef TAccessoryProperty_t TAccessoryProperties_t;

typedef enum
{
  ACCESSORY_CONNECTED_MSG,       ///< Accessory is attached
  ACCESSORY_DISCONNECTED_MSG,     ///< Accessory is detaches
  ACCESSORY_UPDATED_MSG     ///< Accessory is updated
} TAccessoryMsgType_t;

typedef struct
{
  TMsgHdr                  MsgHdr;       ///< Message header
  TAccessoryProperties_t   AccProps;     ///< The properties of the accessory
  TAccessoryId             AccUniqueID;  ///< A unique id
  AS_AccessoryBaseType_t   accBaseType;  ///< The base class of the accessory
  AS_AccessoryType_t       accType;      ///< The unique type of the accessory
} TMsg_AS_Event_t;

typedef struct
{
  TAccessoryProperties_t AccProps;   ///< The properties of the accessory
  TAccessoryId AccUniqueID;          ///< A unique id
} TConnAccElem;

typedef enum
{
  AS_REASON_AC_CCO_REQUIRED,          ///< Used internally
  AS_REASON_VAD_ACTIVATED,            ///< Used by ui settings
  AS_REASON_CALL_HANDLING,            ///< Used by ui call handling
  AS_REASON_PLAY_PAUSE,               ///< Used by mediaplayer standby control
  AS_REASON_TEST,                     ///< May be used in private builds
  AS_NUMBER_OF_REASONS
} AS_PHFButtonPower_Reason_t;

/**
 * Types for USB charging value
 */
typedef enum
{
  AS_USB_CHARGE_OFF,                  ///< Turn off USB charging.
  AS_USB_CHARGE_MAX,                  ///< Allow maximum current.
  AS_USB_LAST_VALUE                   ///< Used for error handling.
} AS_USBCharge_Current_t;

typedef enum
{
  AS_USB_MODE_SHOWMENU          = 0,    // Show menu
  AS_USB_MODE_MASSSTORAGE       = 1,    // Masstorage
  AS_USB_MODE_PICTBRIDGE        = 2,    // Pictbridge
  AS_USB_MODE_MTP               = 128,  // MTP
  AS_USB_MODE_PHONE_MODE        = 252,  // Phone mode several interfaces are exposed (4+8+16+32+64+128).
  AS_USB_MODE_LAST_VALUE                // Invalid/last value
} AS_USBMode_t;

typedef enum
{
  AS_USB_MODE2_SHOWMENU          = 0,    // Show menu
  AS_USB_MODE2_MSC               = 1,    // Masstorage
  AS_USB_MODE2_MTP               = 128,  // MTP
  AS_USB_MODE2_WMC               = 252,  // WMC mode several interfaces are exposed (4+8+16+32+64+128).
  AS_USB_MODE2_WMC_MSC           = 253,  // DOP mass storage and wmc complete are exposed (1+4+8+16+32+64+128).
  AS_USB_MODE2_LAST_VALUE                // Invalid/last value
} AS_USBMode2_t;

typedef enum
{
  AS_DIRECTION_OFF,                   // Usb network: Off
  AS_DIRECTION_PAN,                   // Usb network: Phone as client
  AS_DIRECTION_NAP,                   // Usb network: Phone as server
  AS_DIRECTION_LAST_VALUE             // Invalid/last value
} AS_Direction_t;

typedef enum
{
  AS_ATP_WLAN,
  AS_ATP_DVB_H,
  AS_ATP_GPS
}AS_ATPProtocol_t;


typedef enum
{
  AS_ATP_USB,
  AS_ATP_EDB
}AS_ATPCarrier_t;


typedef enum
{
  AS_ATP_1 = 1,
  AS_ATP_2,
  AS_ATP_3,
  AS_ATP_4,
  AS_ATP_5
}AS_ATPHandle_t;

typedef enum
{
  AS_ATP_CONNECT = 1,            
  AS_ATP_DISCONNECT,         
  AS_ATP_CONNECTED,          
  AS_ATP_DISCONNECTED,       
  AS_ATP_ERROR = 255              
}AS_ATPCommando_t;   


/**
 * Interface for Accessory Server
 */
class IAccessoryServer : public IRoot
{
public:
	virtual int SubscribeToEvents( ICBAccessoryServer *pICBAccessoryServer, TMsgBase msgBase, TClientData clientData, THnd *phSession);
	virtual int UnsubscribeToEvents(THnd hSession);
	virtual int GetConnectedAccessories2(AS_AccessoryInformationList_t* pConnAccList, FUint32 *count);
	virtual int IsPHFConnected(TBool *pPHFConnected);
	virtual int PHFButtonPower(TBool enabled, AS_PHFButtonPower_Reason_t reason);
	virtual int SetUSB_Charging(AS_USBCharge_Current_t USBcharging);
	virtual int GetUSBMode(AS_USBMode_t *pUSBMode, AS_Direction_t *pDirection);
	virtual int GetUSBMode2(AS_USBMode2_t *pUSBMode, AS_Direction_t *pDirection);
	virtual int RegisterToAccessoryServerEvents(TApplicationId AppId, TMsgBase MsgBase);
	virtual int ASMayRetrieveSettings(FUint32 dummy);
}

/**
 * Interface for creating new Accessory Server
 */
class IAccessoryServerManager : public IRoot
{
public:
	virtual int Create(IShell* pIShell, IAccessoryServer** ppIAccessoryServer); // 1198F5C4 DCD loc_11255F48+1
}
