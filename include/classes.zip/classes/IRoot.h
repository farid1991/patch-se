#ifndef __IROOT_H__
#define __IROOT_H__

#include "..\\include\types\Basic_types.h"

class IRoot;

class IRoot
{
public:
  virtual int pguid();
  virtual int QueryInterface( TUuid* pIID, TVoid** ppInterface );
  virtual int AddRef();
  virtual int Release();
};

#endif
