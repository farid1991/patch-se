#ifndef __IREGISTRYKEY_H__
#define __IREGISTRYKEY_H__

#include "..\\classes\IRoot.h"
#include "..\\classes\OPA_types.h"

/**
 * Value type of registry entry. These are the value types/classes that the
 * Registry can hold.
 *
 * @note TBI: Add fixed size type (16 bytes) for UUIDs?
 */
typedef enum
{
  Reg_RegValueType_Unspecified, ///< No data type specified.
  Reg_RegValueType_UInt,    ///< Unsigned integer value.
  Reg_RegValueType_String,  ///< 'char' (null terminated) string value.
  Reg_RegValueType_WString, ///< 'wchar' (null terminated) string value.
  Reg_RegValueType_Binary   ///< Binary/unformatted value, sized in bytes.
} Reg_RegValueType_t;

/**
 * Max size of the Reg_RegValueType_Binary value type.
 */
const TUnsigned REG_MAX_BINARY_SIZE = 1024;

/**
 * Max length of the Reg_RegValueType_String value type, in characters, excluding
 * the null terminator (i.e. strlen-compatible).
 */
const TUnsigned REG_MAX_STRING_LENGTH = (REG_MAX_BINARY_SIZE - 1);

/**
 * Max length of the Reg_RegValueType_WString value type, in characters, excluding
 * the null terminator (i.e. wstrlen-compatible).
 */
const TUnsigned REG_MAX_WSTRING_LENGTH = ((REG_MAX_BINARY_SIZE / 2) - 1);

/**
 * Maximum length of a key name in characters (excl. null terminator).
 */
const TUnsigned REG_MAX_KEY_NAME = 35;

/**
 * Type for key name entries. The name must be null terminated.
 */
typedef TAscii Reg_KeyName_t[REG_MAX_KEY_NAME+1];

/**
 * Maximum length of a value name in characters (excl. null terminator).
 */
const TUnsigned REG_MAX_VALUE_NAME = 35;

/**
 * Type for value name entries. The name must be null terminated.
 */
typedef TAscii Reg_ValueName_t[REG_MAX_VALUE_NAME+1];

/**
 * The deepest allowable sub-key chain. Example, "/first/second/third" has a depth
 * of three. A key's values are considered to have the same depth as their parent.
 */
const TUnsigned REG_MAX_KEY_DEPTH = 8;

/**
 * Type describing the properties of a value entry.
 *
 * @note TBD: Add Flags describing various properties of a Value. These would e.g.
 * describe setting and customization-related properties as: "changed by user",
 * "customized", "user lock" et cetera. Type would prob. be TUnsigned.
 */
typedef struct
{
  Reg_RegValueType_t valueType; ///< The (data) type of the Value.
  TUnsigned dataSize; ///< The size (in bytes) of the data (strings: incl. nullt.).
} RegKey_ValueInfo_t;

/**
 * IRegistryKey. Used to query and manipulate a key's subelements (sub keys
 * and values). Closes key when destroyed.
 *
 * @note TBD: A method Get(Sub)KeyInfo and a corresponding RegKey_KeyInfo_t
 * might be necessary/desired. Possibly this could reside in IRegistry.
 */
class IRegistryKey : public IUnknown // 0x119A92AC
{
public:
  virtual int EnumSubkeys(TAscii* pKeyName);
  virtual int EnumValues(TAscii* pValueName);
  virtual int CreateSubkey(TAscii* keyName, TBool open);
  virtual int OpenSubkey(TAscii* subkeyName);
  virtual int DeleteSubkey(TAscii * keyName);
  virtual int RenameSubkey(TAscii * keyName, TAscii* newKeyName);
  virtual int GetValue(TAscii* valueName, Reg_RegValueType_t Type, TUnsigned dataSize, TVoid* pData, RegKey_ValueInfo_t* pValueInfo);
  virtual int SetValue(TAscii* valueName, Reg_RegValueType_t Type, TUnsigned dataSize, TVoid* pData);
  virtual int DeleteValue(TAscii* valueName);
  virtual int RenameValue(TAscii* valueName, TAscii* NewName);
  virtual int RestateValue(TAscii* valueName);
  virtual int GetValueInfo(TAscii* valueName, RegKey_ValueInfo_t* pValueInfo);
  virtual int GetKeyPath(TUnsigned bufferSize, TAscii* pKeyPath);
};


#endif
