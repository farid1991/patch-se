#ifndef __ISEMCREGISTRYMANAGER_H__
#define __ISEMCREGISTRYMANAGER_H__

#include "..\\classes\IRoot.h"
#include "..\\classes\IRegistry.h"
#include "..\\classes\IRegistryAccess.h"

UUID IID_ISEMCRegistryManager = { 0x42,0xC7,0x45,0x0F,0x21,0x46,0xB7,0x9A,0x29,0x99,0xF4,0x21,0x6A,0x26,0x2E,0x88 };
UUID CID_CSEMCRegistryManager = { 0x84,0xA2,0x98,0x5A,0x91,0x3E,0x4B,0x7E,0xBE,0xB3,0x7E,0xFC,0xFC,0xF0,0xB0,0xEB };

class ISEMCRegistryManager : public IUnknown // 0x119AA4B8
{
public:
  virtual int CreateRegistry(IRegistry** ppIRegistry);
  virtual int CreateRegistryAccess(IRegistryAccess** ppIRegistryAccess);
  virtual int CreateRegistryNotificationsProvider(void** ppIRegistryNotificationsProvider);
};

#endif
