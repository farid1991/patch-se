#ifndef __ISEMCREGISTRYMANAGER_H__
#define __ISEMCREGISTRYMANAGER_H__

#include "..\\classes\IRoot.h"
#include "..\\classes\IRegistryKey.h"

/**
 * @defgroup IRegistry_G Registry Main Interface
 * @{
 *
 * @par Overview
 * IRegistry.idl is the main interface file for the Registry
 *
 * @par Description
 * The IRegistry interface specifies methods to access keys in the Registry.
 * These keys, and their content, are manipulated under Transactions, which
 * are also controlled here.
 * TODO: Add description of registry (keys, values etc) and structure. WHat
 * is it etc?
 *
 * @par Examples
 * - @ref Registry_Examples_G
 *
 *
 * @par Related pages
 * - @ref IRegistryKey_G
 * - @ref IRegistryAccess_G
 */

/**
 * This enum describes the various classes of transactions
 * available for registry operations.
 */
typedef enum
{
  /**
   * All operations are commited as soon as they are completed.
   * TODO: Explain.
   * This transaction class should be sufficient for most applications.
   */
  Reg_RegistryTransactionClass_AutoCommit,
  /**
   * <b>*** NOT IMPLEMENTED!! *** </b><br>
   * NOTE: Using this transaction class will default to an 
   *       auto-commit transaction component.
   *
   * Full transaction behaviour with transaction separation according to
   * ISO/ANSI level 3 (Repeatable Reads).
   * This means that if any of the altering operations in the transaction
   * fails on commit, none of them will take effect. Until the transaction
   * is commited, any changes made to @b Values will not be visible to other
   * transactions until the transaction is commited.
   * Changes to structure (creating/removing Keys and Values) will be visible
   * in an ongoing transaction when changes are commited by other (ongoing)
   * transactions.
   *
   * @note ISO/ANSI level 2 (Read committed) will likely prove sufficient and
   * will be the main fallback if the overhead of level 3 proves to great.
   */
  Reg_RegistryTransactionClass_Full,
  /**
   * TBD. Only non-atomic (?) read-operations can complete under this transaction
   * type.
   */
  Reg_RegistryTransactionClass_ReadOnly
} Reg_RegistryTransactionClass_t;


class IRegistry : public IUnknown // 0x119A91C8
{
public:
  virtual int BeginTransaction(Reg_RegistryTransactionClass_t transactionClass);
  virtual int EndTransaction(bool CommitChanges);
  virtual int FlushTransaction(bool CommitChanges);
  virtual int OpenKey(char * AbsoluteKeyPath, IRegistryKey** ppIRegistryKey);
  virtual int CreateKey(char * AbsoluteKeyPath, IRegistryKey** ppIRegistryKey);
  virtual int EnableValidatingKeys();
  virtual int DisableValidatingKeys();
};


#endif
