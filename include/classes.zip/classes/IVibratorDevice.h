#ifndef __IVIBRATORDEVICE_H__
#define __IVIBRATORDEVICE_H__

#include "..\\classes\IRoot.h"
#include "..\\classes\Time_types.h"

typedef FUint8  TVibratorDeviceDutyCycle;

typedef enum
{
  VIBRATOR_DEVICE_MODE_OFF,		
  VIBRATOR_DEVICE_MODE_ON,
  VIBRATOR_DEVICE_MODE_ON_IF_SILENCE
} TVibratorDeviceMode;


class IVibratorDevice: public IUnknown
{
public:
    virtual int GetMode( TVibratorDeviceMode* pVibratorMode );
    virtual int SetMode( TVibratorDeviceMode VibratorMode );
    virtual int TurnOff( void );
    virtual int TurnOn( TMillisecond Period, TVibratorDeviceDutyCycle DutyCycle );
}

#endif
