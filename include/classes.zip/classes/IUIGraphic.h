#include "..\\classes\IRoot.h"

class IUIGraphics : public IUnknown
{
public:
  virtual int  GetForegroundColor( UIThemeColor_t colorType, TColour* pColor );
  virtual int  GetBackgroundColor( UIThemeColor_t colorType, TColour* pColor );
  virtual int  GetStringWidth( IFont* pIFont, TChar* pString, TUnsigned strLen, FUint16* pStrWidth );
  virtual int  DrawString( IUnknown* pGC /*ICanvas* pICanvas*/,
						   IFont* pIFont,
						   TColour color,
						   TChar* pString,
						   TUnsigned strLen,
						   UITextAlignment_t alignment,
						   TCoordinate x,
						   TCoordinate y,
						   TUnsigned width,
						   TUnsigned height );
  virtual int  DrawIUIText( IUnknown* pGC /*ICanvas* pICanvas*/, 
							IFont* pIFont, 
							TColour color, 
							IUIText* pIUIText, 
							UITextAlignment_t alignment, 
							TCoordinate x, 
							TCoordinate y, 
							TUnsigned width,
							TUnsigned height );  
  virtual int  DrawBackground( IUnknown* pGC /*ICanvas* pICanvas*/,
							   UIBackgroundManagerImage_t image,
							   TColour color,
							   TCoordinate srcX,
							   TCoordinate srcY,
							   TCoordinate dstX,
							   TCoordinate dstY,
							   TUnsigned width,
							   TUnsigned height );
  virtual int  DrawFrame( IUnknown* pGC /*ICanvas* pICanvas*/,
						  TCoordinate x,
						  TCoordinate y,
						  TUnsigned width,
						  TUnsigned height,
						  TColour foreground,
						  TColour background );
  virtual int  FlushCaches();
  virtual int  MatchFont( UIGraphicsFontFace_t face,UIGraphicsFontStyle_t style,UIGraphicsFontSize_t size,IFont** ppIFont);
  virtual int  GetBackgroundImageSize( UIBackgroundManagerImage_t image, TUnsigned* pWidth, TUnsigned* pHeight );    
};
