#ifndef _IUIIMAGEMANAGER_H_
#define _IUIIMAGEMANAGER_H_

#include "..\\include\classes\IRoot.h"
#include "..\\include\classes\IUIImage.h"

class IUIImageManager : public IRoot
{
public:
   virtual RVoid CreateFromPath(wchar_t* pDir, wchar_t* pName, char* pMime, int mimeLength, IUIImage** ppIUIImage);
   virtual void unk_1(void);
   virtual void unk_2(void);
   virtual void unk_3(void);
   virtual void unk_4(void);
   virtual void unk_5(void);
   virtual void unk_6(void);
};

#endif
