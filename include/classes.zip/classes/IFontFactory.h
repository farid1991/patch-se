#ifndef _IFONTFACTORY_H_
#define _IFONTFACTORY_H_

#include "..\\include\classes\IRoot.h"
#include "..\\include\classes\IFont.h"

#include "..\\include\types\UIFont_types.h"
#include "..\\include\types\UIFontParam_types.h"

class IFontFactory: public IRoot
{
public:
#if defined(DB3150v1)
  virtual void unk1();
  virtual void unk2();
  virtual void unk3();
#elif defined(DB3200) || defined(DB3210) || defined(DB3350)
  virtual int GetFont(TUIFontFace Face,TUIFontSize Size, TUIFontStyle Style, IFont** pFont);
  virtual int GetDefaultFont(IFont** ppFont);
  virtual int GetDefaultFontSettings(TUIFontSize Size, TUIFontParam* pFontData);
  virtual int CreateDefaultFont(TUIFontParam * pfontData, IFont** pFont);
  virtual int CreateFontFromFamilyName(IRoot* pIFamilyName, TUIFontParam* pfontData, IFont** ppFont);
  virtual int CreateFontFromFile(IRoot* pIFullPath, TUIFontParam* pFontData, IFont** ppFont);
#endif
};

#endif
