#ifndef __IMUSICSERVERMANAGER_H__
#define __IMUSICSERVERMANAGER_H__

#include "..\\interface\IRoot.h"
#include "..\\interface\IMusicServer.h"

class IMusicServerManager;

class IMusicServerManager: public IRoot
{
public:
  virtual int CreateMusicServer(void* pIShell, IMusicServer** pIMusicServer );
  virtual int method1();
};

#endif
