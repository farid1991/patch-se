#ifndef __ISHELL_H__
#define __ISHELL_H__

#include "..\\include\interface\IRoot.h"
#include "..\\include\interface\Basic_types.h"

class IShell: public IRoot
{
public:
  virtual int AllocateMemory( TUnsigned Size, void** ppBuffer ); 
  virtual int CreateMsg( TMsgBase Base, TMsgId Id, TSize Size, void **ppMsg ); 
  virtual int CompareUUID( UUID* pIID1, UUID* pIID2 ); 
  virtual int FreeMsg( void** ppMsg );  
  virtual int CreateInstance( UUID* pCID, UUID* pIID, void** ppInterfacePointer );
  virtual int FreeMemory( void** ppBuffer );
  virtual int MarkInterfacesInMsg( void** ppMsg, void** ppInterfacePointer );
  virtual int ReallocateMemory( TUnsigned Size, void** ppBuffer );
  virtual int ReleaseInterfacesInMsg( void** ppMsg);
  virtual bool IsKindOfInterface( void* pInterface, UUID* pIID );
  virtual int InvalidateCallbackInterface( void* pICB );
  virtual int GetCallerExecutionShell( void** ppIExecutionShell );
};

#endif
