#ifndef __IPHONELOCK_H__
#define __IPHONELOCK_H__

#include "..\\interface\IRoot.h"

class IPhoneLock;

typedef enum
{
  PHONELOCK_OFF,
  PHONELOCK_ON,
  PHONELOCK_AUTO,
  PHONELOCK_UNAVAILABLE
}TPhoneLockStatus;

class IPhoneLock: public IRoot
{
public:
  virtual int unk_0x10();
  virtual int unk_0x14();
  virtual int PhoneLockStatus(TPhoneLockStatus* lockstatus);
};

#endif
