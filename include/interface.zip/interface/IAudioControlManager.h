#ifndef _IAUDIOCONTROLMANAGER_H_
#define _IAUDIOCONTROLMANAGER_H_

#include "..\\include\interface\IRoot.h"
#include "..\\include\interface\IAudioControl.h"

class IAudioControlManager;

class IAudioControlManager: public IRoot
{
public:
  virtual int CreateAudioControl(IAudioControl** pIAudioControl);
};

#endif
