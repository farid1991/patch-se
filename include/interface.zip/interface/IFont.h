#ifndef _IFONT_H_
#define _IFONT_H_

#include "..\\include\interface\IRoot.h"
#include "..\\include\types\UIFont_types.h"

class IFont: public IRoot
{
public:
  virtual int GetFace(TUIFontFace* buf);
  virtual int GetSize(TUIFontSize* buf);
  virtual int GetStyle(TUIFontStyle* buf);
  virtual int GetFontAscent(long* pAscent);
  virtual int GetFontHeight(long* font_size);
  virtual int IsBold();
  virtual int IsItalic();
  virtual int IsPlain();
  virtual int IsUnderlined();
  virtual int GetFontStyle(IRoot* pIUIFontStyle);
};
#endif
