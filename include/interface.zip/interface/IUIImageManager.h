#ifndef _IUIIMAGEMANAGER_H_
#define _IUIIMAGEMANAGER_H_

#include "..\\include\interface\IRoot.h"
#include "..\\include\interface\ICanvas.h"
#include "..\\include\interface\IUIImage.h"

class IUIImageManager : public IRoot
{
public:
   virtual RVoid CreateFromPath(wchar_t* pDir, wchar_t* pName, char* pMime, int mimeLength, IUIImage** ppIUIImage);
   virtual RVoid CreateFromCanvas(ICanvas* pICanvas, IUIImage** ppIUIImage);
   virtual void unk_2(void);
   virtual void unk_3(void);
   virtual void unk_4(void);
   virtual void unk_5(void);
   virtual RVoid Draw(IUIImage* pIUIImage, ICanvas* pICanvas, TRectangle targetRect);
};

#endif
