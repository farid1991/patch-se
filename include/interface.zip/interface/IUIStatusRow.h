#ifndef _IUISTATUSROW_H_
#define _IUISTATUSROW_H_

#include "..\\include\interface\IRoot.h"

class IUIStatusrow;

class IUIStatusrow : public IRoot
{
public:
  virtual int ShowTrayIcon( wchar_t icon, char show );
  virtual int BlinkTrayIcon( wchar_t icon, int mode );
#if defined(DB3200) || defined(DB3210) || defined(DB3350)
  virtual int ShowTrayClock( int display, char show );
#endif
};

#endif