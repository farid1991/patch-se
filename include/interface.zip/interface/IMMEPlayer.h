#ifndef __IMMEPLAYER_H__
#define __IMMEPLAYER_H__

#include "..\\include\classes\IUnknown.h"
#include "..\\include\types\IMMETypes.h"


class IMMEPlayer: public IUnknown
{
public:
  virtual int GetHandle( int* handle );
  virtual int GetState( TMMEState* state );
  virtual int GetTime( TMMETime* elapsedTime );
  virtual int SetTime( TMMETime* offsetTime );
  virtual int SetDisplayAppearance( TRectangle* TMMEVideoArea );
  virtual int Play( int unk_null, bool repeat );
  virtual int Pause();
  virtual int SetFastForwardRewindBoundaryConditions( TMMEWindCondition windCondition );
  virtual int SetWindTimerInterval( int time );
  virtual int StartFastForward();
  virtual int StopFastForward();
  virtual int StartRewind();
  virtual int StopRewind();
  virtual int SlowMotion();
  virtual int SetFadeDownOnInterrupted( TMMEFadeDirection fadeDirection );
  virtual int StartAudioFade();
  virtual int Mute();
  virtual int UnMute();
  virtual int SetVolume();
  virtual int GetVolume();
};

#endif
