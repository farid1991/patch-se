#ifndef __IMETADATA_H__
#define __IMETADATA_H__

#include "..\\include\interface\IRoot.h"
#include "..\\include\types\IMetaData_types.h"

class IMetaData;

typedef struct
{
  wchar_t artist[0x100];
  wchar_t title[0x100];
  wchar_t album[0x100];
  wchar_t year[0x100];
  wchar_t genre[0x100];
  wchar_t x6[0x100];
  wchar_t x7[0x100];
  IMetaData* pMetaData;
}METADATA_DESC;

class IMetaData: public IRoot
{
public:
  virtual int SetFile( wchar_t* fpath, wchar_t* fname);
  virtual int unk_0x14( void* unk1, void* unk2 );
  virtual int GetTag( int tagID, wchar_t* tag );
  virtual int GetTrackNum( int unk, int* track_num );
  virtual int GetCoverInfo( COVER_INFO_DESC* cover_info );
  virtual int unk_0x24();
  virtual int unk_0x28();
  virtual int unk_0x2C();
  //virtual int IsHaveCover(wchar_t* path, wchar_t* name);
};

#endif
