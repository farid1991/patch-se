#ifndef __IFMRADIO_H__
#define __IFMRADIO_H__

#include "..\\interface\IRoot.h"
#include "..\\interface\OPA_types.h"
#include "..\\interface\ICBFMRadio.h"
#include "..\\interface\FMRadio_types.h"

UUID CID_IFMRadio = { 0xEB,0x43,0x06,0x17,0xE6,0xA8,0x4F,0x15,0x9C,0x60,0xA9,0x55,0xB2,0xF8,0x46,0x9F };
UUID IID_IFMRadio = { 0xEA,0x43,0x06,0x17,0xE6,0xA8,0x4F,0x15,0x9C,0x60,0xA9,0x55,0xB2,0xF8,0x46,0x9F };

class IFMRadio: public IRoot // G502_R1FA037 0x11998790
{
public:
    virtual int EnableAntennaAmplifier( TBool enable);							//0x10
    virtual int SubscribeToFMRadio( ICBFMRadio* pICBFMRadio, TMsgBase msgBase, TClientData clientData, THnd* pSubscriptionHandle);
    virtual int UnsubscribeToFMRadio( THnd subscriptionHandle);					//0x18
    virtual int GetSupportedFunctionality( FMRadio_FunctionalityBitfield_t* pSupportedFunctionality);
    virtual int SetPowerMode( FMRadio_PowerMode_t mode);						//0x20
    virtual int GetFrequencyBand( FMRadio_FrequencyBand_t* pBand);				//0x24
    virtual int SetFrequencyBand( FMRadio_FrequencyBand_t band);				//0x28
    virtual int SetFrequencyPrecision( FMRadio_FrequencyPrecision_t precision);	//0x2C
    virtual int SetProgram( FUint16 frequency, FUint16 programIdentifier);		//0x30
    virtual int GetProgram( FUint16* pFrequency, FUint16* pProgramIdentifier);	//0x34
    virtual int SearchFrequency( FMRadio_Search_Direction_t direction);			//0x38
    virtual int StopSearchFrequency( void );									//0x3C
    virtual int StartAutoStore( FUint8 listSize);								//0x40
    virtual int StopAutoStore( void );											//0x44
    virtual int Mute( FMRadio_MuteOption_t muteMode, TBool mute);				//0x48
    virtual int ForceMono( TBool forceMono);									//0x4C
    virtual int GetStereoReception( TBool* pStereoOn);							//0x50
    virtual int ActivateRDSFunctionality( FMRadio_RDSFlag_Bitfield_t RDSFlags);	//0x54
    virtual int GetPSName( TChar* pPSNameBuffer, FUint8 bufferSize); 			//0x58
    virtual int StopAFupdateAndPIsearch( void );								//0x5C
    virtual int CheckRDSstatus( void );											//0x60
    virtual int GetTPstatus( TBool *pTPstatus );								//0x64
};


#endif
