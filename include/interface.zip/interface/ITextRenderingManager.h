#ifndef __IUITEXTRENDERINGMANAGER_H__
#define __IUITEXTRENDERINGMANAGER_H__

#include "..\\interface\IRoot.h"
#include "..\\interface\ITextRenderingFactory.h"

class ITextRenderingManager;

class ITextRenderingManager: public IRoot
{
public:
  virtual int GetTextRenderingFactory(ITextRenderingFactory** pTextRenderingFactory);
  virtual int GetFontConfigFilePath(IRoot** pIString);
  virtual int GetFontEngineConfigFilePath(IRoot** pIString);
};

#endif
