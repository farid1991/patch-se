#ifndef __IUITEXTFACTORY_H__
#define __IUITEXTFACTORY_H__

#include "..\\interface\IRoot.h"
#include "..\\interface\IRichText.h"
#include "..\\interface\IRichTextLayout.h"

class ITextRenderingFactory: public IRoot
{
public:
  virtual int CreateFontResourceManager(IRoot* pIUIFontResourceManager);
  virtual int CreateFontStyleManager(IRoot* pIUIFontStyleManager);
  virtual int CreateRichText(IRichText ** pRichText);
  virtual int CreateTextContainer(IRoot* pIUITextContainer);
  virtual int CreateRichTextLayout(IRichText * pRichText, IRoot* pIUIRichTextLayoutControl, IRoot* pIUIRichTextLayoutOptions, IRichTextLayout** ppRichTextLayout);
  virtual int CreateSingleLineLayout(IRoot* pIUIRichTextLayoutControl, IRoot* pIUIRichTextLayoutOptions, IRoot** pIUISingleLineLayout);
  virtual int CreateRichTextLayoutControl(IRoot** ppIUIRichTextLayoutControl);
  virtual int CreateRichTextLayoutOptions(IRoot** ppIUIRichTextLayoutOptions);
  virtual int CreatePolygon(IRoot** ppIUIPolygon);
  virtual int CreateBasicTextHandler(IRoot** ppIUIBasicTextHandling);
};

#endif
