#ifndef __IACCELEROMETER_H__
#define __IACCELEROMETER_H__

#include "..\\]include\interface\IRoot.h"

UUID IID_IAccelerometerManager = {0xB7,0x6C,0x85,0x42,0x43,0x72,0x43,0x24,0x98,0x86,0xFB,0xD6,0xF5,0x26,0x1F,0x10};
UUID CID_IAccelerometerManager = {0xF7,0xA4,0x58,0x00,0xD8,0x96,0x47,0xDE,0x9C,0x04,0x6A,0x30,0xD5,0x75,0x50,0x43};


////////////////////////////////////////////////////////////////////////////////
// Interface class declarations
class ICBAccelerometerData;
class IAccelerometerManager;
class IAccelerometerControl;
class IAccelerometerData;

////////////////////////////////////////////////////////////////////////////////
// ICBAccelerometerData
class ICBAccelerometerData: public IRoot
{
   virtual TVoid OnEvent(RVoid status, FUint32 eventType, TClientData clientData);
}

////////////////////////////////////////////////////////////////////////////////
// IAccelerometerManager
class IAccelerometerManager: public IRoot
{
public:
   virtual RVoid CreateAccelerometerControl(IAccelerometerControl** ppIAccelerometerControl);
   virtual RVoid CreateAccelerometerData(IAccelerometerData** ppIAccelerometerData);
};

////////////////////////////////////////////////////////////////////////////////
// IAccelerometerControl interface
class IAccelerometerControl: public IRoot
{
public:
  virtual RVoid SetInternalSamplingRate(Acc_InternalSamplingRate_t SampleRate);
  virtual RVoid GetInternalSamplingRate(Acc_InternalSamplingRate_t *pSampleRate);
  virtual RVoid SetDetectScale(Acc_ScaleSelection_t Scale);
  virtual RVoid GetDetectScale(Acc_ScaleSelection_t *pScale);
  virtual RVoid SetAxesUsage(Acc_Axes_OP_t x_axis, Acc_Axes_OP_t y_axis, Acc_Axes_OP_t z_axis);
  virtual RVoid GetAxesUsage(Acc_Axes_OP_t *px_axis, Acc_Axes_OP_t *py_axis, Acc_Axes_OP_t *pz_axis);
  virtual RVoid PowerOnChip(void);
  virtual RVoid PowerOffChip(void);
};


////////////////////////////////////////////////////////////////////////////////
// IAccelerometerData interface
class IAccelerometerData: public IRoot
{
  public:
  virtual RVoid GetRawAxisValues(FUint8 *pX, FUint8 *pY, FUint8 *pZ);
  virtual RVoid GetMaxAxisValues(FSint32 *pX, FSint32 *pY, FSint32 *pZ);
  virtual RVoid GetMinAxisValues(FSint32 *pX, FSint32 *pY, FSint32 *pZ);
  virtual RVoid ResetMaxMinValues(void);
  virtual RVoid GetAxisValues(FSint32 *pX, FSint32 *pY, FSint32 *pZ);
  virtual RVoid SubscribeToEvents(ICBAccelerometerData *pICBAccelerometerData,
                                  TMsgBase msgBase,
                                  TClientData clientData,
                                  Acc_PollFrequency_t freq,
                                  Acc_Channels_t channels,
                                  FUint32 samples,
                                  Acc_Filter_Type_t filterType,
                                  Acc_Filter_Param_t filterParam,
                                  THnd *pSession);
  virtual RVoid Unsubscribe(THnd hSession);
  virtual RVoid GetNeededBufferSize(THnd hSession, Acc_BufferSize_t *pSize);
  virtual RVoid GetBuffer(THnd hSession, FSint16 *pBuffer, Acc_BufferSize_t length, FUint32 *pNbrOfMissedBuffers);
};



#endif
