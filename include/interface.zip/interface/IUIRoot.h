#ifndef __IUIROOT_H__
#define __IUIROOT_H__

#include "..\\include\interface\IRoot.h"

typedef FUint32 TUIHash;

class IUIRoot : public IRoot
{
public:
  /**
   * Get a hash value of the component, can be used to compare two interfaces
   * to see if they belong to the same component
   */
  virtual int GetComponentHash( TUIHash* pHash);
}

#endif
